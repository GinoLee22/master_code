package ClosestPair;

import java.awt.geom.Point2D;
import java.util.Arrays;


/**
 * Created by GinoLee on 2017/2/12.
 */
public class ClosestPair {
    // private variable
    public Point2D point1;
    public Point2D point2;
    public double minDistance = Double.POSITIVE_INFINITY;

    public ClosestPair(Point2D[] points) {
        int size = points.length;
        // sort by x-coordinate
        Point2D[] sortByX = new Point2D[size];
        for (int i = 0; i < size; i++) {
            sortByX[i] = points[i];
        }
        Arrays.sort(sortByX, new XComparator());
        // sort by y-coordinate
        Point2D[] sortByY = new Point2D[size];
        for (int i = 0; i < size; i++) {
            sortByY[i] = points[i];
        }
        Arrays.sort(sortByY, new YComparator());
        // help array to store all the points within the distance 2d and sorted by y-coordinate
        Point2D[] help = new Point2D[size];
        divideAndConquer(sortByX, sortByY, help, 0, size - 1);
    }

    // divide and conquer algorithm for closest pair
    private double divideAndConquer(Point2D[] sortByX, Point2D[] sortByY, Point2D[] help, int left, int right) {
        /**
         * base case
         */
        if (right <= left) {
            return Double.POSITIVE_INFINITY;
        }
        /**
         * recursion part
         */
        int mid = (left + right) / 2;
        Point2D midPoint = sortByX[mid];
        // the distance
        double d1 = divideAndConquer(sortByX, sortByY, help, left, mid);
        double d2 = divideAndConquer(sortByX, sortByY, help, mid + 1, right);
        double d = Math.min(d1, d2);

        // extract the points within the strips of the minimum distance 2d.
        // All the element in front of help array is the extracted points
        int m = 0;
        for (int i = left; i <= right; i++) {
            double currentD = Math.abs(sortByY[i].getX() - midPoint.getX());
            if (currentD < d) {
                help[m] = sortByY[i];
                m++;
            }
        }
        // calculate the distance between the left side and right side
        for (int i = 0; i < m; i++) {
            for (int j = i + 1; (j < m) && (help[j].getY() - help[i].getY()) < d; j++) {
                double currentD = help[j].distance(help[i]);
                if (currentD < d) {
                    d = currentD;
                    if (d < minDistance) {
                        minDistance = d;
                        point1 = help[i];
                        point2 = help[j];
                    }
                }
            }
        }
        return d;
    }

    public static void main(String[] args) {
        int n = 9;
        Point2D points[] = new Point2D.Double[n];
        points[0] = new Point2D.Double(1, 1);
        points[1] = new Point2D.Double(2, 1);
        points[2] = new Point2D.Double(2.5, 2);
        points[3] = new Point2D.Double(3, 2.5);
        points[4] = new Point2D.Double(4, 3);
        points[5] = new Point2D.Double(5, 1);
        points[6] = new Point2D.Double(6, 2);
        points[7] = new Point2D.Double(7, 1);
        points[8] = new Point2D.Double(4.5, 3);
        ClosestPair cp = new ClosestPair(points);
        System.out.println(cp.minDistance + "\n" + cp.point1.toString() + "\n" + cp.point2.toString());
    }
}
